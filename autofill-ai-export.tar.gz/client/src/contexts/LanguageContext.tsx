import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    'nav.title': 'Autofill.Ai',
    'nav.tagline': 'Form bharna ab AI ka kaam hai!',
    'nav.login': 'Login',
    'nav.language': 'हिंदी',
    'home.title': 'Form bharna ab AI ka kaam hai!',
    'home.subtitle': 'Fill your profile once, auto-fill all Indian forms instantly. Download PDFs with your signature and photo embedded.',
    'home.getStarted': 'Get Started',
    'dashboard.title': 'Dashboard',
    'dashboard.quickActions': 'Quick Actions',
    'dashboard.fillNewForm': 'Fill New Form',
    'dashboard.browseLibrary': 'Browse form library',
    'dashboard.viewHistory': 'View History',
    'dashboard.recentActivity': 'Recent Activity',
    'dashboard.notifications': 'Notifications',
    'profile.title': 'Profile Information',
    'profile.personalDetails': 'Personal Details',
    'profile.contactDocuments': 'Contact & Documents',
    'profile.addressInfo': 'Address Information',
    'profile.photoSignature': 'Photo & Signature',
    'profile.save': 'Save Profile',
    'forms.title': 'Form Library',
    'forms.search': 'Search forms...',
    'forms.allCategories': 'All Categories',
    'forms.autoFillable': 'Auto-fillable',
    'forms.partialData': 'Partial data',
    'forms.deadline': 'Deadline',
    'history.title': 'Form History',
    'history.formName': 'Form Name',
    'history.category': 'Category',
    'history.status': 'Status',
    'history.date': 'Date',
    'history.actions': 'Actions',
    'status.completed': 'Completed',
    'status.pending': 'Pending Info',
    'status.inProgress': 'In Progress',
    'modal.welcome': 'Welcome Back',
    'modal.signIn': 'Sign in to access your forms',
    'modal.continueGoogle': 'Continue with Google',
    'modal.signInOTP': 'Sign in with OTP',
    'modal.continueEmail': 'Or continue with email',
    'modal.emailPlaceholder': 'Email address',
    'modal.passwordPlaceholder': 'Password',
    'modal.signInButton': 'Sign In',
    'modal.noAccount': "Don't have an account?",
    'modal.signUp': 'Sign up',
  },
  hi: {
    'nav.title': 'Autofill.Ai',
    'nav.tagline': 'फॉर्म भरना अब AI का काम है!',
    'nav.login': 'लॉग इन',
    'nav.language': 'English',
    'home.title': 'फॉर्म भरना अब AI का काम है!',
    'home.subtitle': 'अपनी प्रोफाइल एक बार भरें, सभी भारतीय फॉर्म तुरंत भरें। अपने हस्ताक्षर और फोटो के साथ PDF डाउनलोड करें।',
    'home.getStarted': 'शुरू करें',
    'dashboard.title': 'डैशबोर्ड',
    'dashboard.quickActions': 'त्वरित कार्य',
    'dashboard.fillNewForm': 'नया फॉर्म भरें',
    'dashboard.browseLibrary': 'फॉर्म लाइब्रेरी देखें',
    'dashboard.viewHistory': 'इतिहास देखें',
    'dashboard.recentActivity': 'हाल की गतिविधि',
    'dashboard.notifications': 'सूचनाएं',
    'profile.title': 'प्रोफाइल जानकारी',
    'profile.personalDetails': 'व्यक्तिगत विवरण',
    'profile.contactDocuments': 'संपर्क और दस्तावेज',
    'profile.addressInfo': 'पता जानकारी',
    'profile.photoSignature': 'फोटो और हस्ताक्षर',
    'profile.save': 'प्रोफाइल सहेजें',
    'forms.title': 'फॉर्म लाइब्रेरी',
    'forms.search': 'फॉर्म खोजें...',
    'forms.allCategories': 'सभी श्रेणियां',
    'forms.autoFillable': 'स्वचालित भरा जा सकता है',
    'forms.partialData': 'आंशिक डेटा',
    'forms.deadline': 'अंतिम तिथि',
    'history.title': 'फॉर्म इतिहास',
    'history.formName': 'फॉर्म का नाम',
    'history.category': 'श्रेणी',
    'history.status': 'स्थिति',
    'history.date': 'तारीख',
    'history.actions': 'कार्य',
    'status.completed': 'पूर्ण',
    'status.pending': 'जानकारी लंबित',
    'status.inProgress': 'प्रगति में',
    'modal.welcome': 'वापस स्वागत है',
    'modal.signIn': 'अपने फॉर्म तक पहुंचने के लिए साइन इन करें',
    'modal.continueGoogle': 'Google के साथ जारी रखें',
    'modal.signInOTP': 'OTP के साथ साइन इन करें',
    'modal.continueEmail': 'या ईमेल के साथ जारी रखें',
    'modal.emailPlaceholder': 'ईमेल पता',
    'modal.passwordPlaceholder': 'पासवर्ड',
    'modal.signInButton': 'साइन इन',
    'modal.noAccount': 'कोई खाता नहीं है?',
    'modal.signUp': 'साइन अप करें',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const value = {
    language,
    setLanguage,
    t,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};
